import React from 'react';
import EmployeeFilter from './EmployeeFilter.jsx';
import EmployeeAdd from './EmployeeAdd.jsx';

function EmployeeRow(props) {
  return (
    <tr>
      <td>{props.employee.id}</td>
      <td>{props.employee.name}</td>
    </tr>
  );
}

function EmployeeTable(props) {
  return (
    <table>
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
        </tr>
      </thead>
      <tbody>
        {props.employees.map((employee) => (
          <EmployeeRow key={employee.id} employee={employee} />
        ))}
      </tbody>
    </table>
  );
}

export default class EmployeeList extends React.Component {
  constructor() {
    super();
    this.state = {
      employees: [
        { id: 1, name: 'Alice Johnson' },
        { id: 2, name: 'Bob Smith' },
        { id: 3, name: 'Carol Lee' },
        { id: 4, name: 'Dave Brown' },
      ],
    };
    this.handleAdd = this.handleAdd.bind(this);
  }

  handleAdd(employee) {
    const nextId =
      Math.max(0, ...this.state.employees.map((e) => e.id)) + 1;
    this.setState({
      employees: [...this.state.employees, { id: nextId, name: employee.name }],
    });
  }

  render() {
    return (
      <div>
        <h1>Employees</h1>
        <EmployeeFilter />
        <hr />
        <EmployeeAdd onAdd={this.handleAdd} />
        <hr />
        <EmployeeTable employees={this.state.employees} />
      </div>
    );
  }
}
