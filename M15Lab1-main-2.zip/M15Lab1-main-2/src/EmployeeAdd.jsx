import React from 'react';

export default class EmployeeAdd extends React.Component {
  constructor() {
    super();
    this.state = { name: '' };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
    this.setState({ name: e.target.value });
  }

  handleSubmit(e) {
    e.preventDefault();
    const name = this.state.name.trim();
    if (!name) return;
    this.props.onAdd({ name });
    this.setState({ name: '' });
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input
          name="name"
          value={this.state.name}
          onChange={this.handleChange}
          placeholder="Name"
        />
        <button type="submit">Add</button>
      </form>
    );
  }
}
