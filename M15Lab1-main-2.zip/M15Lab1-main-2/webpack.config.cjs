const path = require('path');

module.exports = {
  entry: './src/employees.jsx',
  output: {
    path: path.join(__dirname, 'public'),
    filename: 'employees.bundle.js',
  },
  mode: 'development',
  devtool: false,
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
        },
      },
    ],
  },
  resolve: {
    extensions: ['.js', '.jsx'],
  },
};
