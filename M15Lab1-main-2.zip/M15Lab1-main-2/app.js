import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const envPort = process.env.PORT;
const FALLBACKS = [5000, 5001, 5002, 5003];

function startListening(candidates) {
  const port = candidates[0];
  if (port === undefined) {
    console.error('No free port. Try: PORT=5010 npm start');
    process.exit(1);
  }
  const server = app.listen(port, () => {
    if (envPort === undefined && port !== 5000) {
      console.log(
        '(Port 5000 is busy — often AirPlay on Mac. Using the URL below, or turn off AirPlay in System Settings → AirDrop & Handoff.)'
      );
    }
    console.log(`Server listening on http://localhost:${port}`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE' && !envPort && candidates.length > 1) {
      server.close(() => startListening(candidates.slice(1)));
    } else if (err.code === 'EADDRINUSE') {
      console.error(`\nPort ${port} is already in use.\n`);
      process.exit(1);
    } else {
      throw err;
    }
  });
}

if (envPort !== undefined) {
  const p = Number.parseInt(envPort, 10);
  startListening(Number.isNaN(p) ? [5000] : [p]);
} else {
  startListening(FALLBACKS);
}
