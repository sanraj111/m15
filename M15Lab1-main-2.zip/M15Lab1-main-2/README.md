# M15 Lab 1 — Employee UI with Webpack

This lab splits the React employee UI into separate modules (`EmployeeList`, `EmployeeAdd`, `EmployeeFilter`) and uses **Webpack** to compile the entry file and dependencies into a single browser bundle: **`public/employees.bundle.js`**. **Express** serves the `public` folder and sends `index.html` for `/`.

## Prerequisites

- [Node.js](https://nodejs.org/) (LTS recommended)

## Install

```bash
cd module01
npm install
npm run build
```

`npm run build` produces **`public/employees.bundle.js`** (required for the page to load).

## Run (two terminals)

**Terminal 1 — Webpack in watch mode** (rebuilds the bundle when you edit `src/*.jsx`):

```bash
npm run watch:bundle
```

**Terminal 2 — Express server** (tries **5000** first, then **5001–5003** if 5000 is taken):

```bash
npm start
```

Open the URL shown in the terminal (often `http://localhost:5000`). If 5000 is in use, use the printed port instead.

If **5000** is busy (common on macOS when **AirPlay Receiver** uses it), turn **AirPlay Receiver** off under **System Settings → General → AirDrop & Handoff**, or rely on the automatic fallback / `PORT=5010 npm start`.

## Project layout

| Path | Purpose |
|------|---------|
| `src/employees.jsx` | Entry: imports `EmployeeList`, mounts with `ReactDOM.render` into `#content` |
| `src/EmployeeList.jsx` | Default export: `EmployeeList`; internal `EmployeeRow` and `EmployeeTable` |
| `src/EmployeeAdd.jsx` | Add-employee form (class component) |
| `src/EmployeeFilter.jsx` | Filter placeholder (class component) |
| `webpack.config.cjs` | Bundles `src/employees.jsx` → `public/employees.bundle.js` |
| `public/index.html` | `<div id="content">` and `<script src="employees.bundle.js">` |
| `app.js` | Express: static `public/`, `GET /` → `index.html`, listens on **5000** (fallback **5001–5003**), or `PORT` |

## npm scripts

| Script | Command |
|--------|---------|
| `npm start` | `nodemon app.js` |
| `npm run build` | One-off Webpack build |
| `npm run watch:bundle` | Webpack `--watch` |

## What to verify

- After editing **`src/*.jsx`**, the bundle updates (with watch running) and a browser refresh shows changes.
- The page shows the employee table, the add form, and the filter placeholder.
